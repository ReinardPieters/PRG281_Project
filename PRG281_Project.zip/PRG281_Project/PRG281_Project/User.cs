﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG281_Project
{
    internal class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public double TotalIncome { get; set; }
        public double TotalExpenses { get; set; }
        public double TotalSavings { get; set; }
    }
}
