﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG281_Project
{
    interface iFinancialOperation
    {
        public void Execute();
    }
}
